from distutils.core import setup
setup(name="my_ctrller",version="0.1",author="Youqian_Mei")